import React from 'react';

interface ArrowLogoProps {
  size?: number;
  animated?: boolean;
  className?: string;
}

export const ArrowLogo: React.FC<ArrowLogoProps> = ({ 
  size = 40, 
  animated = false, 
  className = "" 
}) => {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="relative">
        <svg 
          width={size} 
          height={size} 
          viewBox="0 0 100 100" 
          className={animated ? 'animate-pulse' : ''}
        >
          {/* Teal Arrow */}
          <path
            d="M20 30 L60 50 L20 70 L30 50 Z"
            fill="#00B8D9"
            className={animated ? 'animate-bounce' : ''}
            style={animated ? { animationDelay: '0s', animationDuration: '2s' } : {}}
          />
          
          {/* Purple Triangle */}
          <path
            d="M15 45 L25 35 L25 55 Z"
            fill="#A259FF"
            className={animated ? 'animate-bounce' : ''}
            style={animated ? { animationDelay: '0.3s', animationDuration: '2s' } : {}}
          />
        </svg>
        
        {/* Animated dots for thinking state */}
        {animated && (
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 flex gap-1">
            <div className="w-1 h-1 bg-teal-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
            <div className="w-1 h-1 bg-teal-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-1 h-1 bg-teal-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
          </div>
        )}
      </div>
      
      <div>
        <h1 className="text-xl font-bold text-gray-900">Arrow AI</h1>
        <p className="text-xs text-gray-500">Multimedia Assistant</p>
      </div>
    </div>
  );
};