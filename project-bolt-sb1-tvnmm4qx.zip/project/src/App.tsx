import React, { useState, useRef, useEffect } from 'react';
import { Send, Settings, HelpCircle, User, Menu, ArrowRight, MessageSquare, History, Bookmark, Mic, Paperclip, Plus, Search, Sparkles, Image, FileText, Music, Video, X, MicOff, Volume2, VolumeX, Download, Eye, Play, Pause } from 'lucide-react';
import { ArrowLogo } from './components/ArrowLogo';

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: string;
  isTyping?: boolean;
  attachments?: Attachment[];
}

interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'audio' | 'video' | 'document';
  url: string;
  size: string;
}

interface KnowledgeBase {
  [key: string]: {
    keywords: string[];
    response: string;
    category: string;
  };
}

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm Arrow AI, your intelligent multimedia assistant. I can help you with text, images, audio, documents, and much more. You can upload files, use voice commands, or simply type your questions. What would you like to explore today?",
      isUser: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Enhanced knowledge base with multimedia support
  const knowledgeBase: KnowledgeBase = {
    'image processing': {
      keywords: ['image', 'photo', 'picture', 'visual', 'graphics', 'editing'],
      response: "I can help you with image-related tasks! Here's what I can assist with:\n\n• **Image Analysis**: Describe uploaded images, identify objects and scenes\n• **Photo Editing Tips**: Composition, lighting, color correction techniques\n• **File Formats**: JPEG, PNG, WebP, SVG - when to use each format\n• **Optimization**: Reducing file sizes while maintaining quality\n• **Design Principles**: Visual hierarchy, color theory, typography in images\n• **Tools**: Photoshop, GIMP, Canva, Figma recommendations\n\nFeel free to upload an image and I'll analyze it for you, or ask specific questions about image processing!",
      category: 'Multimedia'
    },
    'audio processing': {
      keywords: ['audio', 'sound', 'music', 'voice', 'recording', 'podcast'],
      response: "I'm here to help with all things audio! My capabilities include:\n\n• **Audio Analysis**: Understanding uploaded audio files and their characteristics\n• **Recording Tips**: Microphone setup, room acoustics, noise reduction\n• **Music Production**: DAW recommendations, mixing, mastering basics\n• **Podcast Creation**: Planning, recording, editing, and distribution\n• **Voice Enhancement**: Clarity improvement, noise removal techniques\n• **File Formats**: MP3, WAV, FLAC, AAC - choosing the right format\n\nUpload an audio file for analysis, or ask about specific audio production techniques!",
      category: 'Multimedia'
    },
    'document analysis': {
      keywords: ['document', 'pdf', 'text', 'file', 'analysis', 'reading'],
      response: "I can help you work with various document types effectively:\n\n• **Document Review**: Analyzing uploaded PDFs, Word docs, and text files\n• **Content Summarization**: Key points extraction and executive summaries\n• **Format Conversion**: Best practices for different document formats\n• **Organization**: File naming, folder structures, version control\n• **Collaboration**: Sharing, commenting, and review workflows\n• **Accessibility**: Making documents readable for all users\n\nUpload a document and I'll help you analyze, summarize, or work with its content!",
      category: 'Multimedia'
    },
    'voice commands': {
      keywords: ['voice', 'speak', 'talk', 'verbal', 'speech', 'dictation'],
      response: "Voice interaction makes our conversation more natural! Here's what I support:\n\n• **Voice Input**: Speak your questions instead of typing\n• **Speech-to-Text**: Accurate transcription of your voice commands\n• **Voice Responses**: I can read my answers aloud to you\n• **Hands-Free Mode**: Perfect for multitasking or accessibility\n• **Multiple Languages**: Support for various languages and accents\n• **Voice Commands**: Special commands for navigation and control\n\nTry clicking the microphone button to start voice interaction, or enable voice mode for continuous conversation!",
      category: 'Interface'
    },
    'react': {
      keywords: ['react', 'jsx', 'component', 'hook', 'state', 'props'],
      response: "React is a powerful JavaScript library for building user interfaces. Key concepts include:\n\n• **Components**: Reusable UI building blocks\n• **JSX**: JavaScript syntax extension for writing HTML-like code\n• **Hooks**: Functions like useState, useEffect for managing state and side effects\n• **Props**: Data passed between components\n• **Virtual DOM**: Efficient rendering system\n• **State Management**: Local state, Context API, Redux\n\nWould you like me to explain any specific React concept or help with code examples?",
      category: 'Programming'
    },
    'javascript': {
      keywords: ['javascript', 'js', 'function', 'variable', 'array', 'object', 'async', 'promise'],
      response: "JavaScript is a versatile programming language essential for web development. Core features include:\n\n• **Variables**: let, const, var for data storage\n• **Functions**: Reusable code blocks, arrow functions\n• **Objects & Arrays**: Data structures for organizing information\n• **Async Programming**: Promises, async/await for handling asynchronous operations\n• **DOM Manipulation**: Interacting with web page elements\n• **ES6+ Features**: Destructuring, modules, template literals\n\nWhat specific JavaScript topic would you like to dive deeper into?",
      category: 'Programming'
    },
    'artificial intelligence': {
      keywords: ['ai', 'artificial intelligence', 'machine learning', 'deep learning', 'neural network'],
      response: "Artificial Intelligence is transforming how we solve complex problems. Key areas include:\n\n• **Machine Learning**: Algorithms that learn from data\n• **Deep Learning**: Neural networks with multiple layers\n• **Natural Language Processing**: Understanding and generating human language\n• **Computer Vision**: Analyzing and interpreting visual information\n• **Reinforcement Learning**: Learning through interaction and feedback\n• **Ethics**: Responsible AI development and deployment\n\nWhich aspect of AI interests you most? I can provide detailed explanations or practical examples.",
      category: 'Technology'
    },
    'productivity': {
      keywords: ['productivity', 'time management', 'efficiency', 'workflow', 'organization'],
      response: "Effective productivity combines smart strategies with the right tools. Key principles:\n\n• **Time Blocking**: Dedicating specific time slots to focused work\n• **Priority Matrix**: Distinguishing urgent vs. important tasks\n• **Pomodoro Technique**: 25-minute focused work sessions with breaks\n• **Digital Tools**: Task managers, calendars, automation\n• **Minimizing Distractions**: Creating focused work environments\n• **Energy Management**: Working during your peak performance hours\n\nProductivity isn't about doing more—it's about doing the right things effectively. What specific productivity challenge can I help you tackle?",
      category: 'Business'
    }
  };

  const generateIntelligentResponse = (userInput: string, attachments?: Attachment[]): string => {
    const input = userInput.toLowerCase();
    
    // Handle file uploads
    if (attachments && attachments.length > 0) {
      const fileTypes = attachments.map(att => att.type).join(', ');
      const fileNames = attachments.map(att => att.name).join(', ');
      
      let response = `I can see you've uploaded ${attachments.length} file(s): ${fileNames}\n\n`;
      
      if (attachments.some(att => att.type === 'image')) {
        response += "🖼️ **Image Analysis**: I can help analyze visual content, suggest improvements, or explain design principles.\n\n";
      }
      
      if (attachments.some(att => att.type === 'audio')) {
        response += "🎵 **Audio Processing**: I can discuss audio quality, format optimization, or production techniques.\n\n";
      }
      
      if (attachments.some(att => att.type === 'document')) {
        response += "📄 **Document Review**: I can help summarize content, suggest improvements, or discuss formatting.\n\n";
      }
      
      response += "What specific aspect of these files would you like me to help you with?";
      return response;
    }

    // Check for exact matches or keyword matches
    for (const [key, data] of Object.entries(knowledgeBase)) {
      if (input.includes(key) || data.keywords.some(keyword => input.includes(keyword))) {
        return data.response;
      }
    }

    // Handle voice-related queries
    if (input.includes('voice') || input.includes('speak') || input.includes('audio')) {
      return "I support full voice interaction! Here's how to use voice features:\n\n🎤 **Voice Input**: Click the microphone button to speak your questions\n🔊 **Voice Output**: Enable voice mode to hear my responses\n🎯 **Voice Commands**: Use natural speech for hands-free interaction\n📱 **Mobile Friendly**: Works great on phones and tablets\n\nTry saying 'Hello Arrow AI' or ask any question using your voice!";
    }

    // Handle file/upload queries
    if (input.includes('file') || input.includes('upload') || input.includes('attach')) {
      return "I support multiple file types for rich interactions:\n\n📎 **Documents**: PDF, Word, text files for analysis and summarization\n🖼️ **Images**: JPEG, PNG, WebP for visual analysis and feedback\n🎵 **Audio**: MP3, WAV for audio processing and transcription\n🎬 **Video**: MP4, WebM for content analysis\n\nSimply drag and drop files, use the attachment button, or click the specific file type buttons. What type of file would you like to work with?";
    }

    // Handle common question patterns
    if (input.includes('how to') || input.includes('how do')) {
      return "I'd be happy to provide step-by-step guidance! To give you the most helpful instructions, could you be more specific about what you'd like to learn? For example:\n\n• Programming concepts (React, Python, JavaScript)\n• Creative projects (writing, design)\n• Problem-solving approaches\n• Technical skills\n• File processing and multimedia tasks\n\nWhat specific topic would you like detailed instructions for?";
    }

    if (input.includes('what is') || input.includes('explain')) {
      return "I can provide clear explanations on a wide range of topics! I specialize in:\n\n• **Technology**: Programming, AI, web development\n• **Multimedia**: Image, audio, video processing\n• **Science**: Physics, mathematics, research methods\n• **Business**: Entrepreneurship, productivity, strategy\n• **Creative**: Writing, design principles, innovation\n\nWhat concept would you like me to break down and explain in detail?";
    }

    if (input.includes('help') || input.includes('assist')) {
      return "I'm here to help with comprehensive support! I can assist you with:\n\n🔧 **Technical Support**: Coding, debugging, system design\n📚 **Learning**: Explanations, tutorials, study guidance\n💡 **Creative Projects**: Writing, brainstorming, problem-solving\n📊 **Analysis**: Data interpretation, research, planning\n🎯 **Productivity**: Organization, workflow optimization\n📁 **File Processing**: Documents, images, audio, video\n🎤 **Voice Interaction**: Hands-free communication\n\nWhat specific challenge are you facing? Upload files, use voice commands, or type your questions!";
    }

    if (input.includes('thank') || input.includes('thanks')) {
      return "You're very welcome! I'm glad I could help. Feel free to ask me anything else—whether it's a follow-up question, uploading files for analysis, using voice commands, or exploring completely new topics. I'm here to support your learning and problem-solving journey! 😊";
    }

    // Greeting responses
    if (input.includes('hello') || input.includes('hi') || input.includes('hey')) {
      return "Hello! Great to meet you! I'm Arrow AI, and I'm excited to help you explore ideas, solve problems, and work with multimedia content. I'm particularly good at:\n\n• Explaining complex concepts clearly\n• Analyzing uploaded files (images, audio, documents)\n• Voice interaction and hands-free communication\n• Programming and technology guidance\n• Creative writing and brainstorming\n• Problem-solving and analysis\n\nTry uploading a file, using voice commands, or simply ask me anything. What's on your mind today?";
    }

    // Default intelligent response
    return `That's an interesting question about "${userInput}". While I don't have specific information on that exact topic in my current knowledge base, I can help you approach it systematically:\n\n• **Research Strategy**: I can guide you on how to find reliable sources\n• **Related Topics**: I might know about similar or connected subjects\n• **Multimedia Support**: Upload relevant files for deeper analysis\n• **Voice Discussion**: Use voice mode for more natural conversation\n• **Problem-Solving Framework**: We can break down complex questions into manageable parts\n\nCould you provide more context, upload relevant files, or use voice input to help me give you more targeted assistance?`;
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Voice recognition setup
  const startVoiceRecognition = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      
      recognition.onstart = () => {
        setIsRecording(true);
      };
      
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsRecording(false);
      };
      
      recognition.onerror = () => {
        setIsRecording(false);
      };
      
      recognition.onend = () => {
        setIsRecording(false);
      };
      
      recognition.start();
    } else {
      alert('Speech recognition not supported in this browser');
    }
  };

  // Text-to-speech
  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 0.8;
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      
      speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  // File handling
  const handleFileUpload = (files: FileList | null, type?: string) => {
    if (!files) return;
    
    Array.from(files).forEach(file => {
      const url = URL.createObjectURL(file);
      const attachment: Attachment = {
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: getFileType(file.type, type),
        url,
        size: formatFileSize(file.size)
      };
      
      setAttachments(prev => [...prev, attachment]);
    });
    
    setShowAttachmentMenu(false);
  };

  const getFileType = (mimeType: string, forcedType?: string): 'image' | 'audio' | 'video' | 'document' => {
    if (forcedType) {
      return forcedType as 'image' | 'audio' | 'video' | 'document';
    }
    
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (mimeType.startsWith('video/')) return 'video';
    return 'document';
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(att => att.id !== id));
  };

  // Drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleSendMessage = async () => {
    if (inputText.trim() || attachments.length > 0) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: inputText || "Shared files",
        isUser: true,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        attachments: attachments.length > 0 ? [...attachments] : undefined
      };
      
      setMessages(prev => [...prev, newMessage]);
      const currentInput = inputText;
      const currentAttachments = [...attachments];
      setInputText('');
      setAttachments([]);
      setIsTyping(true);
      
      // Simulate typing delay for more natural interaction
      setTimeout(() => {
        const aiResponse: Message = {
          id: messages.length + 2,
          text: generateIntelligentResponse(currentInput, currentAttachments),
          isUser: false,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, aiResponse]);
        setIsTyping(false);
        
        // Auto-speak in voice mode
        if (isVoiceMode) {
          speakText(aiResponse.text);
        }
      }, 1200);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const suggestionPrompts = [
    "Upload an image for analysis",
    "Try voice commands",
    "Explain quantum computing",
    "Help me learn React",
    "Creative writing tips",
    "Productivity strategies"
  ];

  const handleSuggestionClick = (suggestion: string) => {
    setInputText(suggestion);
  };

  const renderAttachment = (attachment: Attachment) => {
    const iconMap = {
      image: <Image className="w-4 h-4" />,
      audio: <Music className="w-4 h-4" />,
      video: <Video className="w-4 h-4" />,
      document: <FileText className="w-4 h-4" />
    };

    return (
      <div key={attachment.id} className="flex items-center gap-3 p-3 bg-gray-50 border border-gray-200">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {iconMap[attachment.type]}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">{attachment.name}</p>
            <p className="text-xs text-gray-500">{attachment.size}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {attachment.type === 'image' && (
            <button className="p-1 hover:bg-gray-200 transition-colors">
              <Eye className="w-4 h-4 text-gray-600" />
            </button>
          )}
          <button className="p-1 hover:bg-gray-200 transition-colors">
            <Download className="w-4 h-4 text-gray-600" />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div 
      className={`h-screen bg-gray-50 flex ${dragOver ? 'bg-teal-50' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drag overlay */}
      {dragOver && (
        <div className="fixed inset-0 bg-teal-500 bg-opacity-20 flex items-center justify-center z-50 pointer-events-none">
          <div className="bg-white p-8 border-2 border-dashed border-teal-500 text-center">
            <Paperclip className="w-12 h-12 text-teal-500 mx-auto mb-4" />
            <p className="text-lg font-semibold text-gray-900">Drop files here to upload</p>
            <p className="text-sm text-gray-600">Images, audio, documents, and videos supported</p>
          </div>
        </div>
      )}

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => handleFileUpload(e.target.files)}
      />
      <input
        ref={imageInputRef}
        type="file"
        multiple
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFileUpload(e.target.files, 'image')}
      />
      <input
        ref={audioInputRef}
        type="file"
        multiple
        accept="audio/*"
        className="hidden"
        onChange={(e) => handleFileUpload(e.target.files, 'audio')}
      />
      <input
        ref={videoInputRef}
        type="file"
        multiple
        accept="video/*"
        className="hidden"
        onChange={(e) => handleFileUpload(e.target.files, 'video')}
      />

      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 bg-white border-r border-gray-200 flex flex-col overflow-hidden`}>
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg text-gray-900">Conversations</h2>
            <button className="p-2 hover:bg-gray-100 transition-colors">
              <Plus className="w-5 h-5 text-gray-600" />
            </button>
          </div>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
            <input
              type="text"
              placeholder="Search conversations..."
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            <div className="p-4 bg-teal-50 border-l-4 border-teal-500 hover:bg-teal-100 cursor-pointer transition-colors">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-4 h-4 text-teal-600" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">Image Analysis Session</p>
                  <p className="text-xs text-gray-500 mt-1">2 hours ago</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 hover:bg-gray-50 cursor-pointer transition-colors border border-gray-100">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-4 h-4 text-gray-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">Voice Commands Tutorial</p>
                  <p className="text-xs text-gray-500 mt-1">Yesterday</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 hover:bg-gray-50 cursor-pointer transition-colors border border-gray-100">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-4 h-4 text-gray-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">Document Processing</p>
                  <p className="text-xs text-gray-500 mt-1">3 days ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-100">
          <div className="space-y-2">
            <button className="w-full p-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3 border border-gray-200">
              <History className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">View History</span>
            </button>
            <button className="w-full p-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3 border border-gray-200">
              <Bookmark className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Saved Messages</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-gray-100 transition-colors border border-gray-200"
            >
              <Menu className="w-5 h-5 text-gray-600" />
            </button>
            
            <ArrowLogo size={40} />
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsVoiceMode(!isVoiceMode)}
              className={`p-2 transition-colors border border-gray-200 ${
                isVoiceMode ? 'bg-teal-100 text-teal-600' : 'hover:bg-gray-100 text-gray-600'
              }`}
              title="Toggle Voice Mode"
            >
              {isVoiceMode ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
            <button className="p-2 hover:bg-gray-100 transition-colors border border-gray-200">
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 transition-colors border border-gray-200">
              <HelpCircle className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 transition-colors border border-gray-200">
              <User className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </header>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-3xl ${message.isUser ? 'ml-12' : 'mr-12'}`}>
                  <div
                    className={`p-4 border ${
                      message.isUser
                        ? 'bg-teal-500 text-white border-teal-600'
                        : 'bg-white text-gray-900 border-gray-200 shadow-sm'
                    }`}
                  >
                    {message.attachments && message.attachments.length > 0 && (
                      <div className="mb-4 space-y-2">
                        {message.attachments.map(renderAttachment)}
                      </div>
                    )}
                    
                    <div className="whitespace-pre-wrap text-sm leading-relaxed">
                      {message.text}
                    </div>
                    
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-opacity-20">
                      <span className={`text-xs ${message.isUser ? 'text-teal-100' : 'text-gray-500'}`}>
                        {message.timestamp}
                      </span>
                      <div className="flex items-center gap-2">
                        {!message.isUser && (
                          <button
                            onClick={() => speakText(message.text)}
                            className={`text-xs ${message.isUser ? 'text-teal-100 hover:text-white' : 'text-gray-500 hover:text-gray-700'} transition-colors`}
                          >
                            {isSpeaking ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                          </button>
                        )}
                        <button className={`text-xs ${message.isUser ? 'text-teal-100 hover:text-white' : 'text-gray-500 hover:text-gray-700'} transition-colors`}>
                          Copy
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="max-w-3xl mr-12">
                  <div className="p-4 bg-white border border-gray-200 shadow-sm">
                    <div className="flex items-center gap-3">
                      <ArrowLogo size={24} animated={true} />
                      <span className="text-sm text-gray-600">Arrow AI is thinking...</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Attachments Preview */}
        {attachments.length > 0 && (
          <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center gap-2 mb-3">
                <Paperclip className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">
                  {attachments.length} file(s) ready to send
                </span>
              </div>
              <div className="space-y-2">
                {attachments.map(attachment => (
                  <div key={attachment.id} className="flex items-center gap-3 p-2 bg-white border border-gray-200">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      {attachment.type === 'image' && <Image className="w-4 h-4 text-blue-500" />}
                      {attachment.type === 'audio' && <Music className="w-4 h-4 text-green-500" />}
                      {attachment.type === 'video' && <Video className="w-4 h-4 text-red-500" />}
                      {attachment.type === 'document' && <FileText className="w-4 h-4 text-gray-500" />}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{attachment.name}</p>
                        <p className="text-xs text-gray-500">{attachment.size}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => removeAttachment(attachment.id)}
                      className="p-1 hover:bg-gray-100 transition-colors"
                    >
                      <X className="w-4 h-4 text-gray-500" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Suggestion Cards */}
        {messages.length === 1 && (
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
            <div className="max-w-4xl mx-auto">
              <p className="text-sm text-gray-600 mb-4">Try these features:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {suggestionPrompts.map((prompt, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(prompt)}
                    className="p-4 bg-white border border-gray-200 hover:border-teal-300 hover:bg-teal-50 transition-all text-left"
                  >
                    <span className="text-sm font-medium text-gray-800">{prompt}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="bg-white border-t border-gray-200 px-6 py-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-end gap-3">
              {/* Attachment Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowAttachmentMenu(!showAttachmentMenu)}
                  className="p-3 bg-gray-50 border border-gray-200 hover:bg-gray-100 transition-colors"
                >
                  <Paperclip className="w-5 h-5 text-gray-600" />
                </button>
                
                {showAttachmentMenu && (
                  <div className="absolute bottom-full left-0 mb-2 bg-white border border-gray-200 shadow-lg min-w-48">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full p-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3"
                    >
                      <FileText className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">Documents</span>
                    </button>
                    <button
                      onClick={() => imageInputRef.current?.click()}
                      className="w-full p-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3"
                    >
                      <Image className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">Images</span>
                    </button>
                    <button
                      onClick={() => audioInputRef.current?.click()}
                      className="w-full p-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3"
                    >
                      <Music className="w-4 h-4 text-green-500" />
                      <span className="text-sm">Audio</span>
                    </button>
                    <button
                      onClick={() => videoInputRef.current?.click()}
                      className="w-full p-3 text-left hover:bg-gray-50 transition-colors flex items-center gap-3"
                    >
                      <Video className="w-4 h-4 text-red-500" />
                      <span className="text-sm">Video</span>
                    </button>
                  </div>
                )}
              </div>
              
              <div className="flex-1 border border-gray-200 bg-gray-50 focus-within:border-teal-500 focus-within:ring-1 focus-within:ring-teal-500 transition-all">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything, upload files, or use voice commands..."
                  className="w-full p-4 bg-transparent resize-none focus:outline-none text-gray-900 placeholder-gray-500"
                  rows={1}
                  style={{ minHeight: '56px', maxHeight: '120px' }}
                />
              </div>
              
              <button
                onClick={startVoiceRecognition}
                className={`p-3 border transition-colors ${
                  isRecording
                    ? 'bg-red-500 border-red-600 text-white animate-pulse'
                    : 'bg-gray-50 border-gray-200 hover:bg-gray-100 text-gray-600'
                }`}
                title="Voice Input"
              >
                {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
              
              {isSpeaking && (
                <button
                  onClick={stopSpeaking}
                  className="p-3 bg-red-500 border border-red-600 hover:bg-red-600 text-white transition-colors"
                  title="Stop Speaking"
                >
                  <VolumeX className="w-5 h-5" />
                </button>
              )}
              
              <button
                onClick={handleSendMessage}
                disabled={!inputText.trim() && attachments.length === 0}
                className={`p-3 border transition-colors ${
                  inputText.trim() || attachments.length > 0
                    ? 'bg-teal-500 border-teal-600 hover:bg-teal-600 text-white'
                    : 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;